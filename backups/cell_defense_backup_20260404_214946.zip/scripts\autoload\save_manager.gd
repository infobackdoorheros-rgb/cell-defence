extends Node

const SAVE_PATH := "user://cell_defense_save.json"

var _cached_save: Dictionary = {}

func _ready() -> void:
	_cached_save = load_save()

func get_default_save() -> Dictionary:
	return {
		"dna": 0,
		"best_wave": 0,
		"meta_levels": {},
		"social_connections": {},
		"settings": {
			"audio_enabled": true,
			"language": "it"
		}
	}

func get_save() -> Dictionary:
	return _cached_save.duplicate(true)

func load_save() -> Dictionary:
	var defaults: Dictionary = get_default_save()
	if not FileAccess.file_exists(SAVE_PATH):
		return defaults

	var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if file == null:
		return defaults

	var parsed: Variant = JSON.parse_string(file.get_as_text())
	if typeof(parsed) != TYPE_DICTIONARY:
		return defaults

	return _merge_with_defaults(parsed as Dictionary)

func write_save(data: Dictionary) -> void:
	var merged: Dictionary = _merge_with_defaults(_cached_save)
	for key in data.keys():
		merged[key] = data[key]
	_cached_save = _merge_with_defaults(merged)
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file == null:
		push_error("Unable to write save file at %s" % SAVE_PATH)
		return
	file.store_string(JSON.stringify(_cached_save, "\t"))

func _merge_with_defaults(data: Dictionary) -> Dictionary:
	var merged: Dictionary = get_default_save()
	for key in data.keys():
		merged[key] = data[key]
	return merged

func reset_game_progress() -> void:
	var preserved_social: Dictionary = (_cached_save.get("social_connections", {}) as Dictionary).duplicate(true)
	var preserved_settings: Dictionary = (_cached_save.get("settings", {}) as Dictionary).duplicate(true)
	_cached_save = get_default_save()
	_cached_save["social_connections"] = preserved_social
	_cached_save["settings"] = preserved_settings
	write_save(_cached_save)
