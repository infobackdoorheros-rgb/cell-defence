# Cell Defense: Core Immunity

Prototipo Godot 4.x di un auto-shooter survival mobile top-down con progressione runtime, mutazioni e meta progression persistente.

## Struttura Cartelle

`scenes/`
Scene principali, UI e prefab entity.

`scripts/autoload/`
Catalogo contenuti, save JSON e meta progression persistente.

`scripts/managers/`
Manager runtime per wave, shop, mutazioni e risorse.

`scripts/entities/`
Logica del nucleo, nemici, proiettili e pickup ATP.

`scripts/data/`
Classi `Resource` per enemy, upgrade, mutation e wave rules.

`data/`
Contenuti data-driven `.tres` per nemici, upgrade, mutazioni e regole wave.

## Scene Principali

`res://scenes/main_menu.tscn`
Hub iniziale con accesso a run e meta progression.

`res://scenes/run_scene.tscn`
Loop completo di combattimento, HUD, mutazioni e game over.

`res://scenes/laboratory_scene.tscn`
Laboratorio dove spendere il DNA per migliorare gli attributi permanenti della cellula.

## Sistemi Core

`WaveManager`
Genera ondate scalabili, elite e boss ogni 10 wave.

`UpgradeManager`
Calcola stat finali da base + meta + runtime + mutazioni.

`MutationManager`
Gestisce pool sbloccato, roll 1-su-3 e applicazione mutazioni.

`ResourceManager`
Tiene ATP runtime, proiezione DNA, kill stats e ricompensa finale.

`SaveManager` + `MetaProgression`
Persistono DNA, record wave e livelli meta in JSON locale.

## Avvio

1. Apri il progetto con Godot 4.x.
2. Avvia `res://scenes/main_menu.tscn`.
3. Entra in `Laboratorio` per spendere il DNA salvato.
4. Avvia una run dal pulsante `Play`.

## Loop Testabile

1. Le wave partono automaticamente.
2. Il nucleo spara anticorpi in auto.
3. I nemici rilasciano pickup ATP.
4. Gli upgrade runtime sono acquistabili dal pannello in basso.
5. Ogni 4 wave appare la scelta mutazione.
6. Alla morte viene assegnato DNA e il risultato viene salvato.
7. La scena meta applica i bonus persistenti alla run successiva.

## Save

Il salvataggio viene scritto in `user://cell_defense_save.json`.

## TODO Futuri

- Aggiungere rarita mutazioni e weighting meta piu avanzato.
- Introdurre boss con pattern multipli e telegrafi visuali.
- Estendere targeting configurabile via UI.
- Aggiungere audio, VFX e polish mobile.
- Introdurre nuove valute specialistiche e mutazioni sinergiche.
