extends Control
class_name MainMenuUI

const BioUI = preload("res://scripts/ui/bio_ui.gd")
const BioBackdrop = preload("res://scripts/ui/bio_backdrop.gd")
const BioShowcase = preload("res://scripts/ui/bio_showcase.gd")

var _status_chip_label: Label
var _tagline_label: Label
var _feature_labels: Array[Label] = []
var _profile_label: Label
var _hint_label: Label
var _intel_label: Label
var _social_title_label: Label
var _social_note_label: Label
var _social_summary_label: Label
var _social_buttons: Dictionary = {}
var _play_button: Button
var _laboratory_button: Button
var _options_button: Button
var _exit_button: Button

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	BioUI.style_root(self)
	_build_ui()
	if not MetaProgression.profile_changed.is_connected(_refresh_profile):
		MetaProgression.profile_changed.connect(_refresh_profile)
	if not SocialConnectManager.connections_changed.is_connected(_refresh_social_hub):
		SocialConnectManager.connections_changed.connect(_refresh_social_hub)
	if not SettingsManager.language_changed.is_connected(_refresh_texts):
		SettingsManager.language_changed.connect(_refresh_texts)
	_refresh_texts()
	_refresh_profile()
	_refresh_social_hub()

func _build_ui() -> void:
	var backdrop := BioBackdrop.new()
	backdrop.base_color = Color(0.025, 0.048, 0.075, 1.0)
	backdrop.accent_a = Color(0.27, 0.92, 0.82, 0.42)
	backdrop.accent_b = Color(1.0, 0.5, 0.45, 0.25)
	backdrop.accent_c = Color(0.39, 0.74, 1.0, 0.28)
	add_child(backdrop)

	var root := MarginContainer.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_theme_constant_override("margin_left", 26)
	root.add_theme_constant_override("margin_top", 24)
	root.add_theme_constant_override("margin_right", 26)
	root.add_theme_constant_override("margin_bottom", 24)
	add_child(root)

	var layout := VBoxContainer.new()
	layout.add_theme_constant_override("separation", 18)
	root.add_child(layout)

	var top_bar := HBoxContainer.new()
	top_bar.alignment = BoxContainer.ALIGNMENT_CENTER
	layout.add_child(top_bar)

	_status_chip_label = Label.new()
	_status_chip_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_status_chip_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	BioUI.style_body(_status_chip_label, BioUI.COLOR_TEXT, 15)
	_status_chip_label.add_theme_stylebox_override("normal", _make_chip_style(Color(0.09, 0.15, 0.2, 0.82), Color(0.31, 0.87, 0.8, 0.58)))
	top_bar.add_child(_status_chip_label)

	var hero_panel := PanelContainer.new()
	hero_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	hero_panel.custom_minimum_size = Vector2(0.0, 420.0)
	BioUI.style_panel(hero_panel, Color(0.06, 0.1, 0.14, 0.86), Color(0.27, 0.82, 0.78, 0.95), 34, 22)
	layout.add_child(hero_panel)

	var hero_margin := MarginContainer.new()
	hero_panel.add_child(hero_margin)

	var hero_box := VBoxContainer.new()
	hero_box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	hero_box.add_theme_constant_override("separation", 12)
	hero_margin.add_child(hero_box)

	var title := Label.new()
	title.text = "CELL DEFENSE"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	BioUI.style_title(title, 50, Color(0.95, 1.0, 0.98, 1.0))
	hero_box.add_child(title)

	var subtitle := Label.new()
	subtitle.text = "Core Immunity"
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	BioUI.style_heading(subtitle, Color(0.39, 0.96, 0.87, 1.0), 24)
	hero_box.add_child(subtitle)

	_tagline_label = Label.new()
	_tagline_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_tagline_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	BioUI.style_subtitle(_tagline_label, 18)
	hero_box.add_child(_tagline_label)

	var feature_row := HFlowContainer.new()
	feature_row.alignment = FlowContainer.ALIGNMENT_CENTER
	feature_row.add_theme_constant_override("separation", 10)
	hero_box.add_child(feature_row)

	for feature_text in ["", "", ""]:
		var feature_chip := Label.new()
		feature_chip.text = feature_text
		feature_chip.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		BioUI.style_body(feature_chip, BioUI.COLOR_TEXT, 14)
		feature_chip.add_theme_stylebox_override("normal", _make_chip_style(Color(0.08, 0.13, 0.18, 0.86), Color(0.35, 0.9, 0.84, 0.55)))
		feature_row.add_child(feature_chip)
		_feature_labels.append(feature_chip)

	var showcase := BioShowcase.new()
	showcase.size_flags_vertical = Control.SIZE_EXPAND_FILL
	hero_box.add_child(showcase)

	var menu_panel := PanelContainer.new()
	BioUI.style_panel(menu_panel, Color(0.08, 0.13, 0.18, 0.92), Color(1.0, 0.74, 0.38, 0.86), 30, 20)
	layout.add_child(menu_panel)

	var menu_box := VBoxContainer.new()
	menu_box.add_theme_constant_override("separation", 12)
	menu_panel.add_child(menu_box)

	_profile_label = Label.new()
	_profile_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_profile_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	BioUI.style_body(_profile_label, BioUI.COLOR_TEXT, 20)
	menu_box.add_child(_profile_label)

	_hint_label = Label.new()
	_hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_hint_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	BioUI.style_subtitle(_hint_label, 17)
	menu_box.add_child(_hint_label)

	_intel_label = Label.new()
	_intel_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_intel_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	BioUI.style_body(_intel_label, Color(0.78, 0.9, 0.92, 1.0), 16)
	menu_box.add_child(_intel_label)

	var social_panel := PanelContainer.new()
	BioUI.style_panel(social_panel, Color(0.07, 0.12, 0.17, 0.95), Color(0.46, 0.82, 1.0, 0.72), 24, 16)
	menu_box.add_child(social_panel)

	var social_box := VBoxContainer.new()
	social_box.add_theme_constant_override("separation", 8)
	social_panel.add_child(social_box)

	_social_title_label = Label.new()
	_social_title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	BioUI.style_heading(_social_title_label, Color(0.46, 0.82, 1.0, 1.0), 22)
	social_box.add_child(_social_title_label)

	_social_note_label = Label.new()
	_social_note_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_social_note_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	BioUI.style_subtitle(_social_note_label, 15)
	social_box.add_child(_social_note_label)

	_social_summary_label = Label.new()
	_social_summary_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	BioUI.style_body(_social_summary_label, BioUI.COLOR_TEXT, 16)
	social_box.add_child(_social_summary_label)

	var social_flow := HFlowContainer.new()
	social_flow.alignment = FlowContainer.ALIGNMENT_CENTER
	social_flow.add_theme_constant_override("h_separation", 10)
	social_flow.add_theme_constant_override("v_separation", 10)
	social_box.add_child(social_flow)

	for provider_id in SocialConnectManager.get_provider_ids():
		var info: Dictionary = SocialConnectManager.get_provider_info(provider_id)
		var button := Button.new()
		button.alignment = HORIZONTAL_ALIGNMENT_CENTER
		button.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		button.custom_minimum_size = Vector2(150.0, 84.0)
		BioUI.style_button(button, info.get("accent", Color(0.46, 0.82, 1.0, 1.0)), 84.0)
		button.pressed.connect(_on_social_button_pressed.bind(provider_id))
		social_flow.add_child(button)
		_social_buttons[String(provider_id)] = button

	_play_button = Button.new()
	BioUI.style_button(_play_button, Color(0.36, 0.94, 0.84, 1.0), 82.0)
	_play_button.pressed.connect(func() -> void: get_tree().change_scene_to_file("res://scenes/run_scene.tscn"))
	menu_box.add_child(_play_button)

	_laboratory_button = Button.new()
	BioUI.style_button(_laboratory_button, Color(1.0, 0.77, 0.4, 1.0), 82.0)
	_laboratory_button.pressed.connect(func() -> void: get_tree().change_scene_to_file("res://scenes/laboratory_scene.tscn"))
	menu_box.add_child(_laboratory_button)

	_options_button = Button.new()
	BioUI.style_button(_options_button, Color(0.45, 0.82, 1.0, 1.0), 72.0)
	_options_button.pressed.connect(func() -> void: get_tree().change_scene_to_file("res://scenes/options_scene.tscn"))
	menu_box.add_child(_options_button)

	_exit_button = Button.new()
	BioUI.style_button(_exit_button, Color(1.0, 0.5, 0.45, 1.0), 72.0)
	_exit_button.pressed.connect(func() -> void: get_tree().quit())
	menu_box.add_child(_exit_button)

func _refresh_texts(_unused = null) -> void:
	_status_chip_label.text = SettingsManager.t("main.status_chip")
	_tagline_label.text = SettingsManager.t("main.tagline")
	_hint_label.text = SettingsManager.t("main.hint")
	_intel_label.text = SettingsManager.t("main.intel")
	_social_title_label.text = SettingsManager.t("main.social.title")
	_social_note_label.text = SettingsManager.t("main.social.note")
	_play_button.text = SettingsManager.t("common.play")
	_laboratory_button.text = SettingsManager.t("common.laboratory")
	_options_button.text = SettingsManager.t("common.options")
	_exit_button.text = SettingsManager.t("common.exit")

	var feature_keys := ["main.feature.auto", "main.feature.mutations", "main.feature.meta"]
	for index in range(min(_feature_labels.size(), feature_keys.size())):
		_feature_labels[index].text = SettingsManager.t(feature_keys[index])

	_refresh_profile()
	_refresh_social_hub()

func _refresh_profile() -> void:
	_profile_label.text = SettingsManager.t("main.profile") % [MetaProgression.dna, MetaProgression.best_wave]

func _refresh_social_hub() -> void:
	if _social_summary_label != null:
		_social_summary_label.text = SettingsManager.t("main.social.summary") % [SocialConnectManager.get_connected_count(), SocialConnectManager.get_provider_ids().size()]

	for provider_id in SocialConnectManager.get_provider_ids():
		var button := _social_buttons.get(String(provider_id)) as Button
		if button == null:
			continue
		var info: Dictionary = SocialConnectManager.get_provider_info(provider_id)
		var status := SocialConnectManager.get_status(provider_id)
		var action_text := SettingsManager.t("main.social.link")
		match status:
			&"pending":
				action_text = SettingsManager.t("main.social.confirm")
			&"linked":
				action_text = SettingsManager.t("main.social.unlink")
		button.text = "%s\n%s" % [String(info.get("display_name", provider_id)), action_text]

func _on_social_button_pressed(provider_id: StringName) -> void:
	var status := SocialConnectManager.cycle_connection(provider_id)
	var provider_name := String(SocialConnectManager.get_provider_info(provider_id).get("display_name", provider_id))
	match status:
		&"pending":
			_profile_label.text = SettingsManager.t("main.social.pending_message") % [MetaProgression.dna, MetaProgression.best_wave, provider_name]
		&"linked":
			_profile_label.text = SettingsManager.t("main.social.linked_message") % [MetaProgression.dna, MetaProgression.best_wave, provider_name]
		_:
			_refresh_profile()

func _make_chip_style(fill: Color, border: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = fill
	style.border_color = border
	style.set_corner_radius_all(999)
	style.set_border_width_all(2)
	style.content_margin_left = 16
	style.content_margin_right = 16
	style.content_margin_top = 8
	style.content_margin_bottom = 8
	return style
