extends Node

const EnemyData = preload("res://scripts/data/enemy_data.gd")
const UpgradeData = preload("res://scripts/data/upgrade_data.gd")
const MutationData = preload("res://scripts/data/mutation_data.gd")
const WaveRulesData = preload("res://scripts/data/wave_rules_data.gd")

var _enemy_catalog: Dictionary = {}
var _upgrade_catalog: Dictionary = {}
var _mutation_catalog: Dictionary = {}
var _wave_rules: WaveRulesData

func _ready() -> void:
	reload_content()

func reload_content() -> void:
	_enemy_catalog = _load_catalog("res://data/enemies")
	_upgrade_catalog = _load_catalog("res://data/upgrades")
	_mutation_catalog = _load_catalog("res://data/mutations")
	_wave_rules = load("res://data/waves/wave_rules.tres") as WaveRulesData

func get_enemy(enemy_id: StringName) -> EnemyData:
	return _enemy_catalog.get(enemy_id) as EnemyData

func get_upgrade(upgrade_id: StringName) -> UpgradeData:
	return _upgrade_catalog.get(upgrade_id) as UpgradeData

func get_mutation(mutation_id: StringName) -> MutationData:
	return _mutation_catalog.get(mutation_id) as MutationData

func get_all_enemies() -> Array[EnemyData]:
	var result: Array[EnemyData] = []
	for value in _enemy_catalog.values():
		result.append(value as EnemyData)
	return result

func get_runtime_upgrades() -> Array[UpgradeData]:
	return _filter_upgrades_by_layer(&"runtime")

func get_meta_upgrades() -> Array[UpgradeData]:
	return _filter_upgrades_by_layer(&"meta")

func get_runtime_upgrades_by_category(category: StringName) -> Array[UpgradeData]:
	var upgrades: Array[UpgradeData] = []
	for item in get_runtime_upgrades():
		if item.category == category:
			upgrades.append(item)
	upgrades.sort_custom(func(a: UpgradeData, b: UpgradeData) -> bool: return String(a.display_name) < String(b.display_name))
	return upgrades

func get_meta_upgrades_by_category(category: StringName) -> Array[UpgradeData]:
	var upgrades: Array[UpgradeData] = []
	for item in get_meta_upgrades():
		if item.category == category:
			upgrades.append(item)
	upgrades.sort_custom(func(a: UpgradeData, b: UpgradeData) -> bool: return String(a.display_name) < String(b.display_name))
	return upgrades

func get_all_mutations() -> Array[MutationData]:
	var result: Array[MutationData] = []
	for value in _mutation_catalog.values():
		result.append(value as MutationData)
	result.sort_custom(func(a: MutationData, b: MutationData) -> bool: return String(a.display_name) < String(b.display_name))
	return result

func get_wave_rules() -> WaveRulesData:
	return _wave_rules

func _load_catalog(folder_path: String) -> Dictionary:
	var catalog: Dictionary = {}
	var dir := DirAccess.open(folder_path)
	if dir == null:
		push_warning("Missing content folder: %s" % folder_path)
		return catalog

	dir.list_dir_begin()
	while true:
		var file_name := dir.get_next()
		if file_name.is_empty():
			break
		if dir.current_is_dir():
			continue
		if not file_name.ends_with(".tres"):
			continue

		var resource_path := "%s/%s" % [folder_path, file_name]
		var resource := load(resource_path)
		if resource == null:
			continue

		if resource is EnemyData:
			var enemy := resource as EnemyData
			catalog[enemy.enemy_id] = enemy
		elif resource is UpgradeData:
			var upgrade := resource as UpgradeData
			catalog[upgrade.upgrade_id] = upgrade
		elif resource is MutationData:
			var mutation := resource as MutationData
			catalog[mutation.mutation_id] = mutation
	dir.list_dir_end()

	return catalog

func _filter_upgrades_by_layer(layer: StringName) -> Array[UpgradeData]:
	var result: Array[UpgradeData] = []
	for value in _upgrade_catalog.values():
		var upgrade := value as UpgradeData
		if upgrade.layer == layer:
			result.append(upgrade)
	result.sort_custom(func(a: UpgradeData, b: UpgradeData) -> bool: return String(a.display_name) < String(b.display_name))
	return result
