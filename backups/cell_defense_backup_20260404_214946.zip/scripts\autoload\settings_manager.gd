extends Node

signal settings_changed
signal language_changed(language: StringName)
signal audio_changed(enabled: bool)

const DEFAULT_LANGUAGE: StringName = &"it"

const _TRANSLATIONS := {
	"it": {
		"main.status_chip": "IMMUNE DEFENSE PROTOCOL",
		"main.tagline": "Un nucleo vivente resiste a ondate di virus e batteri, adattando la propria biologia in tempo reale.",
		"main.feature.auto": "AUTO-SHOOTER BIOLOGICO",
		"main.feature.mutations": "MUTAZIONI RUNTIME",
		"main.feature.meta": "META PROGRESSION DNA",
		"main.profile": "DNA accumulato: %d\nMiglior risposta immune: wave %d",
		"main.hint": "Costruisci la tua cellula nel Laboratorio, poi entra in arena con una build sempre piu efficiente.",
		"main.intel": "Boss ogni 10 wave. Mutazioni a milestone fisse. Cristalli DNA appaiono in arena e alimentano il Laboratorio.",
		"main.social.title": "Social Hub",
		"main.social.note": "Prototipo account link: apre il provider nel browser e salva lo stato locale del collegamento.",
		"main.social.summary": "Account collegati: %d / %d",
		"main.social.link": "Collega",
		"main.social.confirm": "Conferma",
		"main.social.unlink": "Scollega",
		"main.social.pending_message": "DNA Reservoir: %d\nBest Immune Response: wave %d\n%s aperto nel browser. Premi ancora per confermare il link locale.",
		"main.social.linked_message": "DNA Reservoir: %d\nBest Immune Response: wave %d\n%s collegato nel profilo locale.",
		"common.play": "Play",
		"common.laboratory": "Laboratorio",
		"common.options": "Opzioni",
		"common.main_menu": "Menu Principale",
		"common.exit": "Esci",
		"common.restart": "Ricomincia",
		"common.wave": "Wave",
		"lab.title": "Laboratorio Cellulare",
		"lab.subtitle": "Spendi il DNA raccolto nelle run per potenziare in modo permanente gli attributi del nucleo e sbloccare nuove mutazioni.",
		"lab.dna_block": "DNA disponibile: %d\nMiglior record: wave %d",
		"lab.summary": "Bonus permanenti della prossima run:\nDanno %.1f\nVelocita Attacco %.2f\nHP %.0f\nScudo %.0f\nRigenerazione %.1f/s\nATP x%.2f\nDNA x%.2f\nPickup Radius %.0f\nTargeting %.0f",
		"lab.category.attack": "Attacco",
		"lab.category.defense": "Difesa",
		"lab.category.utility": "Utility",
		"lab.category.mutation": "Mutazioni",
		"lab.blurb.attack": "Incrementa la letalita iniziale e la pressione offensiva del nucleo.",
		"lab.blurb.defense": "Migliora sopravvivenza, stabilita cellulare e recupero.",
		"lab.blurb.utility": "Espande raccolta risorse ed efficienza della run.",
		"lab.blurb.mutation": "Sblocca nuove mutazioni disponibili nel pool runtime.",
		"hud.shop_title": "Adaptive Upgrades",
		"hud.shop_hint": "Runtime",
		"hud.attack": "Attacco",
		"hud.defense": "Difesa",
		"hud.utility": "Utility",
		"hud.mutations": "Mutazioni",
		"hud.subtitle.attack": "Danno, traiettorie e output offensivo.",
		"hud.subtitle.defense": "Integrita, scudi e risposta al contatto.",
		"hud.subtitle.utility": "Raccolta, economia ed evoluzione automatica.",
		"hud.subtitle.mutation": "Effetti biologici speciali attivi nella run.",
		"hud.no_mutations": "Nessuna mutazione attiva.",
		"hud.hp": "HP %.0f / %.0f",
		"hud.shield": "Scudo %.0f / %.0f",
		"hud.arena_ready": "Arena pronta",
		"hud.boss_wave": "BOSS WAVE   Minacce %d",
		"hud.boss_in": "Minacce %d   Boss tra %d",
		"hud.no_bonus": "Nessun bonus attivo",
		"game_over.report": "RUN REPORT",
		"game_over.title": "Run Terminata",
		"game_over.summary": "Wave %d\nNemici Eliminati %d\nElite %d   Boss %d\nCristalli DNA %d\nDNA Guadagnato %d\nRecord %d",
		"mutation.report": "GENE RECOMBINATION",
		"mutation.title": "Scegli una Mutazione",
		"mutation.subtitle": "1 scelta su 3",
		"options.title": "Opzioni",
		"options.subtitle": "Configura audio, lingua e progressione locale del profilo.",
		"options.profile": "DNA %d   Record wave %d",
		"options.audio_title": "Audio",
		"options.audio_on": "Audio: Si",
		"options.audio_off": "Audio: No",
		"options.language_title": "Lingua di gioco",
		"options.language_note": "La lingua aggiorna l'interfaccia del gioco e dei menu principali.",
		"options.reset_title": "Reset Profilo",
		"options.reset_desc": "Azzera DNA, record e tutti gli acquisti del Laboratorio. Impostazioni e collegamenti social restano invariati.",
		"options.reset_button": "Reset Progressi",
		"options.reset_confirm": "Premi di nuovo per confermare il reset",
		"options.reset_done": "Progressi del gioco azzerati.",
		"lang.it": "Italiano",
		"lang.en": "English"
	},
	"en": {
		"main.status_chip": "IMMUNE DEFENSE PROTOCOL",
		"main.tagline": "A living core resists waves of viruses and bacteria while adapting its biology in real time.",
		"main.feature.auto": "BIO AUTO-SHOOTER",
		"main.feature.mutations": "RUNTIME MUTATIONS",
		"main.feature.meta": "DNA META PROGRESSION",
		"main.profile": "DNA Reservoir: %d\nBest Immune Response: wave %d",
		"main.hint": "Shape your cell in the Laboratory, then enter the arena with an ever-stronger build.",
		"main.intel": "Boss every 10 waves. Mutation milestones at fixed intervals. DNA crystals appear in the arena and feed the Laboratory.",
		"main.social.title": "Social Hub",
		"main.social.note": "Prototype account link: opens the provider in the browser and stores local connection state.",
		"main.social.summary": "Connected accounts: %d / %d",
		"main.social.link": "Connect",
		"main.social.confirm": "Confirm",
		"main.social.unlink": "Unlink",
		"main.social.pending_message": "DNA Reservoir: %d\nBest Immune Response: wave %d\n%s opened in your browser. Press again to confirm the local link.",
		"main.social.linked_message": "DNA Reservoir: %d\nBest Immune Response: wave %d\n%s linked in the local profile.",
		"common.play": "Play",
		"common.laboratory": "Laboratory",
		"common.options": "Options",
		"common.main_menu": "Main Menu",
		"common.exit": "Exit",
		"common.restart": "Restart",
		"common.wave": "Wave",
		"lab.title": "Cellular Laboratory",
		"lab.subtitle": "Spend DNA earned in runs to permanently enhance the core and unlock new mutations.",
		"lab.dna_block": "Available DNA: %d\nBest record: wave %d",
		"lab.summary": "Persistent bonuses for the next run:\nDamage %.1f\nAttack Speed %.2f\nHP %.0f\nShield %.0f\nRegeneration %.1f/s\nATP x%.2f\nDNA x%.2f\nPickup Radius %.0f\nTargeting %.0f",
		"lab.category.attack": "Attack",
		"lab.category.defense": "Defense",
		"lab.category.utility": "Utility",
		"lab.category.mutation": "Mutations",
		"lab.blurb.attack": "Increase starting lethality and offensive pressure.",
		"lab.blurb.defense": "Improve survival, stability and recovery.",
		"lab.blurb.utility": "Expand resource collection and run efficiency.",
		"lab.blurb.mutation": "Unlock additional mutations for the runtime pool.",
		"hud.shop_title": "Adaptive Upgrades",
		"hud.shop_hint": "Runtime",
		"hud.attack": "Attack",
		"hud.defense": "Defense",
		"hud.utility": "Utility",
		"hud.mutations": "Mutations",
		"hud.subtitle.attack": "Damage, trajectories and offensive output.",
		"hud.subtitle.defense": "Integrity, shields and contact response.",
		"hud.subtitle.utility": "Collection, economy and automatic evolution.",
		"hud.subtitle.mutation": "Special biological effects active during the run.",
		"hud.no_mutations": "No active mutations.",
		"hud.hp": "HP %.0f / %.0f",
		"hud.shield": "Shield %.0f / %.0f",
		"hud.arena_ready": "Arena ready",
		"hud.boss_wave": "BOSS WAVE   Threats %d",
		"hud.boss_in": "Threats %d   Boss in %d",
		"hud.no_bonus": "No active bonus",
		"game_over.report": "RUN REPORT",
		"game_over.title": "Run Over",
		"game_over.summary": "Wave %d\nEnemies Eliminated %d\nElites %d   Bosses %d\nDNA Crystals %d\nDNA Earned %d\nRecord %d",
		"mutation.report": "GENE RECOMBINATION",
		"mutation.title": "Choose a Mutation",
		"mutation.subtitle": "1 choice out of 3",
		"options.title": "Options",
		"options.subtitle": "Configure audio, language and local profile progression.",
		"options.profile": "DNA %d   Best wave %d",
		"options.audio_title": "Audio",
		"options.audio_on": "Audio: On",
		"options.audio_off": "Audio: Off",
		"options.language_title": "Game Language",
		"options.language_note": "Language updates the core UI across menus and the in-run interface.",
		"options.reset_title": "Reset Profile",
		"options.reset_desc": "Clears DNA, records and all Laboratory purchases. Settings and social links stay untouched.",
		"options.reset_button": "Reset Progress",
		"options.reset_confirm": "Press again to confirm the reset",
		"options.reset_done": "Game progress reset.",
		"lang.it": "Italian",
		"lang.en": "English"
	}
}

var audio_enabled: bool = true
var language: StringName = DEFAULT_LANGUAGE

func _ready() -> void:
	load_settings()
	_apply_audio_state()

func load_settings() -> void:
	var save_data := SaveManager.get_save()
	var settings := save_data.get("settings", {}) as Dictionary
	audio_enabled = bool(settings.get("audio_enabled", true))
	language = StringName(settings.get("language", String(DEFAULT_LANGUAGE)))
	if not _TRANSLATIONS.has(String(language)):
		language = DEFAULT_LANGUAGE

func save_settings() -> void:
	SaveManager.write_save({
		"settings": {
			"audio_enabled": audio_enabled,
			"language": String(language)
		}
	})

func set_audio_enabled(enabled: bool) -> void:
	audio_enabled = enabled
	_apply_audio_state()
	save_settings()
	audio_changed.emit(audio_enabled)
	settings_changed.emit()

func toggle_audio() -> void:
	set_audio_enabled(not audio_enabled)

func set_language(new_language: StringName) -> void:
	if not _TRANSLATIONS.has(String(new_language)):
		return
	language = new_language
	save_settings()
	language_changed.emit(language)
	settings_changed.emit()

func get_available_languages() -> Array[StringName]:
	return [&"it", &"en"]

func get_language_display_name(language_id: StringName) -> String:
	return t("lang.%s" % String(language_id))

func t(key: String) -> String:
	var lang_dict := _TRANSLATIONS.get(String(language), {}) as Dictionary
	if lang_dict.has(key):
		return String(lang_dict[key])
	var fallback := _TRANSLATIONS.get(String(DEFAULT_LANGUAGE), {}) as Dictionary
	return String(fallback.get(key, key))

func _apply_audio_state() -> void:
	var master_index: int = AudioServer.get_bus_index("Master")
	if master_index < 0:
		master_index = 0
	AudioServer.set_bus_mute(master_index, not audio_enabled)
