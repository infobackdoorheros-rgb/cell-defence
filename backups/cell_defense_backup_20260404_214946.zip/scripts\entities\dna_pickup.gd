extends Node2D
class_name DnaPickup

signal collected(amount: int)

var amount: int = 1
var core
var run_scene
var velocity: Vector2 = Vector2.ZERO
var age: float = 0.0

var _rng := RandomNumberGenerator.new()
var _visual_time: float = 0.0
var _spin_speed: float = 0.0

func _ready() -> void:
	_rng.randomize()
	add_to_group("dna_pickups")

func initialize(dna_amount: int, core_ref, run_scene_ref) -> void:
	amount = dna_amount
	core = core_ref
	run_scene = run_scene_ref
	velocity = Vector2.RIGHT.rotated(_rng.randf_range(0.0, TAU)) * _rng.randf_range(12.0, 32.0)
	_spin_speed = _rng.randf_range(0.8, 1.8)
	queue_redraw()

func _physics_process(delta: float) -> void:
	if run_scene != null and run_scene.is_gameplay_paused():
		return
	if core == null or not is_instance_valid(core):
		queue_free()
		return

	age += delta
	_visual_time += delta
	var to_core: Vector2 = core.global_position - global_position
	var distance: float = to_core.length()
	var should_home: bool = distance <= core.get_pickup_radius() or age >= 6.0
	if should_home and distance > 0.0:
		var desired: Vector2 = to_core.normalized() * 250.0
		velocity = velocity.lerp(desired, 0.08)
	else:
		velocity = velocity.lerp(Vector2.ZERO, 0.05)

	rotation += delta * _spin_speed
	global_position += velocity * delta
	queue_redraw()
	if distance <= core.get_core_radius() + 14.0:
		collected.emit(amount)
		queue_free()

func _draw() -> void:
	var pulse: float = 1.0 + (sin(_visual_time * 5.0) * 0.07)
	_draw_glow(Vector2.ZERO, 22.0 * pulse, Color(0.88, 0.5, 1.0, 0.1))
	_draw_glow(Vector2.ZERO, 14.0 * pulse, Color(0.46, 0.78, 1.0, 0.08))

	var points := PackedVector2Array([
		Vector2(0.0, -11.0 * pulse),
		Vector2(9.0, -3.0),
		Vector2(11.0 * pulse, 0.0),
		Vector2(9.0, 3.0),
		Vector2(0.0, 11.0 * pulse),
		Vector2(-9.0, 3.0),
		Vector2(-11.0 * pulse, 0.0),
		Vector2(-9.0, -3.0),
	])
	draw_colored_polygon(points, Color(0.92, 0.55, 1.0, 0.96))
	draw_polyline(points + PackedVector2Array([points[0]]), Color(0.55, 0.84, 1.0, 0.88), 2.0)
	draw_circle(Vector2.ZERO, 4.0, Color(1.0, 0.95, 1.0, 0.95))

	for orbit_index in range(3):
		var orbit_angle: float = (_visual_time * (1.1 + (orbit_index * 0.2))) + (TAU * float(orbit_index) / 3.0)
		var orbit_position := Vector2.RIGHT.rotated(orbit_angle) * (8.0 + (orbit_index * 2.0))
		draw_circle(orbit_position, 2.0, Color(0.74, 0.94, 1.0, 0.8))

func _draw_glow(center: Vector2, radius: float, color: Color) -> void:
	for layer in range(4, 0, -1):
		var layer_t: float = float(layer) / 4.0
		draw_circle(center, radius * layer_t, Color(color.r, color.g, color.b, color.a * layer_t))
