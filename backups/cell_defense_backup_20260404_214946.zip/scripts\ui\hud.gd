extends Control
class_name HUD

const UpgradeManager = preload("res://scripts/managers/upgrade_manager.gd")
const UpgradeData = preload("res://scripts/data/upgrade_data.gd")
const MutationData = preload("res://scripts/data/mutation_data.gd")
const BioUI = preload("res://scripts/ui/bio_ui.gd")

signal upgrade_requested(upgrade_id: StringName)

var _badge_wrap: HFlowContainer
var _bottom_panel: PanelContainer
var _hp_chip: Label
var _shield_chip: Label
var _resource_chip: Label
var _wave_chip: Label
var _dna_chip: Label
var _combat_chip: Label
var _event_label: Label
var _mutation_label: Label
var _category_buttons: Dictionary = {}
var _category_sections: Dictionary = {}
var _upgrade_buttons: Dictionary = {}
var _upgrade_data_by_id: Dictionary = {}
var _selected_category: StringName = &"attack"
var _event_timer: float = 0.0

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_PASS
	BioUI.style_root(self)
	_build_ui()
	set_process(true)

func _process(delta: float) -> void:
	if _event_timer <= 0.0:
		return

	_event_timer = max(_event_timer - delta, 0.0)
	var alpha: float = min(_event_timer / 1.8, 1.0)
	_event_label.visible = _event_timer > 0.0
	_event_label.modulate = Color(1.0, 1.0, 1.0, alpha)

func get_playfield_rect(viewport_size: Vector2) -> Rect2:
	var top_limit: float = 78.0
	if _badge_wrap != null:
		var badges_rect: Rect2 = _badge_wrap.get_global_rect()
		top_limit = max(top_limit, badges_rect.position.y + badges_rect.size.y + 14.0)

	var bottom_limit: float = viewport_size.y * 0.69
	if _bottom_panel != null:
		bottom_limit = _bottom_panel.get_global_rect().position.y - 18.0

	return Rect2(
		Vector2(viewport_size.x * 0.06, top_limit),
		Vector2(viewport_size.x * 0.88, max(bottom_limit - top_limit, 180.0))
	)

func _build_ui() -> void:
	var badge_margin := MarginContainer.new()
	badge_margin.anchor_left = 0.02
	badge_margin.anchor_top = 0.02
	badge_margin.anchor_right = 0.98
	badge_margin.anchor_bottom = 0.16
	badge_margin.add_theme_constant_override("margin_left", 4)
	badge_margin.add_theme_constant_override("margin_top", 2)
	badge_margin.add_theme_constant_override("margin_right", 4)
	badge_margin.add_theme_constant_override("margin_bottom", 2)
	add_child(badge_margin)

	_badge_wrap = HFlowContainer.new()
	_badge_wrap.alignment = FlowContainer.ALIGNMENT_BEGIN
	_badge_wrap.add_theme_constant_override("h_separation", 8)
	_badge_wrap.add_theme_constant_override("v_separation", 8)
	badge_margin.add_child(_badge_wrap)

	_hp_chip = _make_chip_label(Color(0.08, 0.14, 0.18, 0.94), Color(0.35, 0.95, 0.68, 0.88))
	_badge_wrap.add_child(_hp_chip)

	_shield_chip = _make_chip_label(Color(0.08, 0.12, 0.18, 0.94), Color(0.46, 0.84, 1.0, 0.88))
	_badge_wrap.add_child(_shield_chip)

	_resource_chip = _make_chip_label(Color(0.12, 0.17, 0.24, 0.94), Color(1.0, 0.77, 0.41, 0.88))
	_badge_wrap.add_child(_resource_chip)

	_wave_chip = _make_chip_label(Color(0.08, 0.14, 0.2, 0.94), Color(0.35, 0.93, 0.84, 0.88))
	_badge_wrap.add_child(_wave_chip)

	_dna_chip = _make_chip_label(Color(0.12, 0.12, 0.21, 0.94), Color(0.82, 0.56, 1.0, 0.84))
	_badge_wrap.add_child(_dna_chip)

	_combat_chip = _make_chip_label(Color(0.1, 0.14, 0.19, 0.94), Color(1.0, 0.58, 0.48, 0.86))
	_badge_wrap.add_child(_combat_chip)

	_event_label = Label.new()
	_event_label.anchor_left = 0.22
	_event_label.anchor_top = 0.105
	_event_label.anchor_right = 0.78
	_event_label.anchor_bottom = 0.15
	_event_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_event_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_event_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_event_label.visible = false
	BioUI.style_chip(_event_label, Color(0.1, 0.15, 0.2, 0.92), Color(1.0, 0.77, 0.41, 0.86))
	add_child(_event_label)

	_bottom_panel = PanelContainer.new()
	_bottom_panel.anchor_left = 0.02
	_bottom_panel.anchor_top = 0.71
	_bottom_panel.anchor_right = 0.98
	_bottom_panel.anchor_bottom = 0.985
	BioUI.style_panel(_bottom_panel, Color(0.045, 0.075, 0.105, 0.9), Color(1.0, 0.73, 0.39, 0.68), 28, 14)
	add_child(_bottom_panel)

	var bottom_box := VBoxContainer.new()
	bottom_box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	bottom_box.add_theme_constant_override("separation", 10)
	_bottom_panel.add_child(bottom_box)

	var header_row := HBoxContainer.new()
	header_row.add_theme_constant_override("separation", 10)
	bottom_box.add_child(header_row)

	var shop_title := Label.new()
	shop_title.text = SettingsManager.t("hud.shop_title")
	shop_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	BioUI.style_heading(shop_title, Color(1.0, 0.77, 0.42, 1.0), 20)
	header_row.add_child(shop_title)

	var shop_hint := Label.new()
	shop_hint.text = SettingsManager.t("hud.shop_hint")
	BioUI.style_chip(shop_hint, Color(0.1, 0.14, 0.18, 0.95), Color(0.35, 0.93, 0.84, 0.86))
	header_row.add_child(shop_hint)

	var category_row := HFlowContainer.new()
	category_row.add_theme_constant_override("h_separation", 8)
	category_row.add_theme_constant_override("v_separation", 8)
	bottom_box.add_child(category_row)

	_add_category_button(category_row, &"attack", SettingsManager.t("hud.attack"))
	_add_category_button(category_row, &"defense", SettingsManager.t("hud.defense"))
	_add_category_button(category_row, &"utility", SettingsManager.t("hud.utility"))
	_add_category_button(category_row, &"mutation", SettingsManager.t("hud.mutations"))

	var content_box := VBoxContainer.new()
	content_box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content_box.add_theme_constant_override("separation", 8)
	bottom_box.add_child(content_box)

	_build_upgrade_section(content_box, &"attack", SettingsManager.t("hud.attack"), SettingsManager.t("hud.subtitle.attack"))
	_build_upgrade_section(content_box, &"defense", SettingsManager.t("hud.defense"), SettingsManager.t("hud.subtitle.defense"))
	_build_upgrade_section(content_box, &"utility", SettingsManager.t("hud.utility"), SettingsManager.t("hud.subtitle.utility"))
	_build_mutation_section(content_box)
	_set_selected_category(_selected_category)

	_hp_chip.text = SettingsManager.t("hud.hp") % [0.0, 0.0]
	_shield_chip.text = SettingsManager.t("hud.shield") % [0.0, 0.0]
	_resource_chip.text = "ATP --"
	_wave_chip.text = "%s --" % SettingsManager.t("common.wave")
	_dna_chip.text = "DNA --"
	_combat_chip.text = SettingsManager.t("hud.arena_ready")

func _build_upgrade_section(parent: VBoxContainer, category: StringName, title: String, subtitle_text: String) -> void:
	var section := PanelContainer.new()
	section.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	section.size_flags_vertical = Control.SIZE_EXPAND_FILL
	BioUI.style_panel(section, Color(0.065, 0.1, 0.145, 0.9), BioUI.get_category_accent(category), 24, 14)
	parent.add_child(section)
	_category_sections[String(category)] = section

	var box := VBoxContainer.new()
	box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	box.add_theme_constant_override("separation", 8)
	section.add_child(box)

	var heading := Label.new()
	heading.text = title
	BioUI.style_heading(heading, BioUI.get_category_accent(category), 18)
	box.add_child(heading)

	var subtitle := Label.new()
	subtitle.text = subtitle_text
	subtitle.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	BioUI.style_subtitle(subtitle, 13)
	box.add_child(subtitle)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_NEVER
	box.add_child(scroll)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	scroll.add_child(row)

	for upgrade in ContentDB.get_runtime_upgrades_by_category(category):
		_upgrade_data_by_id[String(upgrade.upgrade_id)] = upgrade
		var button := Button.new()
		button.alignment = HORIZONTAL_ALIGNMENT_LEFT
		button.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		button.custom_minimum_size = Vector2(292.0, 104.0)
		BioUI.style_button(button, BioUI.get_category_accent(category), 104.0)
		button.pressed.connect(_on_upgrade_button_pressed.bind(upgrade.upgrade_id))
		row.add_child(button)
		_upgrade_buttons[String(upgrade.upgrade_id)] = button

func _build_mutation_section(parent: VBoxContainer) -> void:
	var section := PanelContainer.new()
	section.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	section.size_flags_vertical = Control.SIZE_EXPAND_FILL
	BioUI.style_panel(section, Color(0.07, 0.1, 0.16, 0.92), Color(1.0, 0.78, 0.42, 0.84), 24, 14)
	parent.add_child(section)
	_category_sections[String(&"mutation")] = section

	var box := VBoxContainer.new()
	box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	box.add_theme_constant_override("separation", 8)
	section.add_child(box)

	var heading := Label.new()
	heading.text = SettingsManager.t("hud.mutations")
	BioUI.style_heading(heading, Color(1.0, 0.78, 0.42, 1.0), 18)
	box.add_child(heading)

	var subtitle := Label.new()
	subtitle.text = SettingsManager.t("hud.subtitle.mutation")
	subtitle.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	BioUI.style_subtitle(subtitle, 13)
	box.add_child(subtitle)

	_mutation_label = Label.new()
	_mutation_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_mutation_label.size_flags_vertical = Control.SIZE_EXPAND_FILL
	BioUI.style_body(_mutation_label, BioUI.COLOR_TEXT, 15)
	_mutation_label.text = SettingsManager.t("hud.no_mutations")
	box.add_child(_mutation_label)

func _add_category_button(parent: HFlowContainer, category: StringName, title: String) -> void:
	var button := Button.new()
	button.text = title
	button.toggle_mode = true
	button.custom_minimum_size = Vector2(124.0, 44.0)
	BioUI.style_button(button, BioUI.get_category_accent(category), 44.0)
	button.pressed.connect(_on_category_button_pressed.bind(category))
	parent.add_child(button)
	_category_buttons[String(category)] = button

func update_run_status(current_hp: float, max_hp: float, current_shield: float, max_shield: float, atp: int, wave: int, dna_preview: int, active_enemies: int) -> void:
	_hp_chip.text = SettingsManager.t("hud.hp") % [current_hp, max_hp]
	_shield_chip.visible = max_shield > 0.0
	_shield_chip.text = SettingsManager.t("hud.shield") % [current_shield, max_shield]
	_resource_chip.text = "ATP %d" % atp
	_wave_chip.text = "%s %d" % [SettingsManager.t("common.wave"), wave]
	_dna_chip.text = "DNA %d" % dna_preview

	if wave % 10 == 0:
		_combat_chip.text = SettingsManager.t("hud.boss_wave") % active_enemies
	else:
		var waves_to_boss: int = 10 - (wave % 10)
		_combat_chip.text = SettingsManager.t("hud.boss_in") % [active_enemies, waves_to_boss]

func refresh_shop(upgrade_manager: UpgradeManager) -> void:
	for key in _upgrade_buttons.keys():
		var upgrade := _upgrade_data_by_id[key] as UpgradeData
		var button := _upgrade_buttons[key] as Button
		var level := upgrade_manager.get_runtime_level(upgrade.upgrade_id)
		var can_buy := upgrade_manager.can_purchase(upgrade.upgrade_id)
		var bonus_text := _build_upgrade_bonus_text(upgrade, level)
		if level >= upgrade.max_level:
			button.text = "%s   Lv.%d/%d MAX\n%s" % [upgrade.display_name, level, upgrade.max_level, bonus_text]
			button.disabled = true
			continue

		var cost := upgrade.get_cost_for_level(level + 1)
		button.text = "%s   Lv.%d/%d   %d ATP\n%s" % [upgrade.display_name, level, upgrade.max_level, cost, bonus_text]
		button.disabled = not can_buy

func set_active_mutations(mutations: Array[MutationData]) -> void:
	if mutations.is_empty():
		_mutation_label.text = SettingsManager.t("hud.no_mutations")
		return

	var lines: Array[String] = []
	for mutation in mutations:
		lines.append("%s\n%s" % [mutation.display_name.to_upper(), mutation.description])
	_mutation_label.text = "\n\n".join(lines)

func show_runtime_event(message: String) -> void:
	_event_label.text = message
	_event_label.visible = true
	_event_label.modulate = Color(1.0, 1.0, 1.0, 1.0)
	_event_timer = 2.2

func _on_upgrade_button_pressed(upgrade_id: StringName) -> void:
	upgrade_requested.emit(upgrade_id)

func _on_category_button_pressed(category: StringName) -> void:
	_set_selected_category(category)

func _set_selected_category(category: StringName) -> void:
	_selected_category = category
	for key in _category_sections.keys():
		var section := _category_sections[key] as Control
		section.visible = key == String(category)
	for key in _category_buttons.keys():
		var button := _category_buttons[key] as Button
		button.button_pressed = key == String(category)

func _make_chip_label(fill: Color, accent: Color) -> Label:
	var label := Label.new()
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	BioUI.style_chip(label, fill, accent)
	return label

func _build_upgrade_bonus_text(upgrade: UpgradeData, level: int) -> String:
	if level <= 0:
		return "Nessun bonus attivo"

	var total_bonus: float = upgrade.value_per_level * level
	if upgrade.display_as_percent:
		return "+%d%%" % int(round(total_bonus * 100.0))

	match upgrade.stat_key:
		&"damage":
			return "+%.1f danni" % total_bonus
		&"attack_speed":
			return "+%.2f colpi/s" % total_bonus
		&"projectile_count":
			return "+%d proiettili" % int(round(total_bonus))
		&"damage_vs_virus_bonus":
			return "+%d%% vs virus" % int(round(total_bonus * 100.0))
		&"damage_vs_bacteria_bonus":
			return "+%d%% vs batteri" % int(round(total_bonus * 100.0))
		&"crit_chance", &"random_attack_upgrade_chance", &"random_defense_upgrade_chance":
			return "+%d%%" % int(round(total_bonus * 100.0))
		&"crit_damage":
			return "x%.2f crit" % (1.75 + total_bonus)
		&"projectile_speed":
			return "+%.0f velocita" % total_bonus
		&"pierce_count":
			return "+%d perforazione" % int(round(total_bonus))
		&"secondary_projectile_chance":
			return "+%d%% secondario" % int(round(total_bonus * 100.0))
		&"max_hp":
			return "+%.0f HP" % total_bonus
		&"regeneration":
			return "+%.1f HP/s" % total_bonus
		&"shield_max":
			return "+%.0f scudo" % total_bonus
		&"shield_regeneration":
			return "+%.1f scudo/s" % total_bonus
		&"contact_retaliation":
			return "+%.0f riflessi" % total_bonus
		&"dna_gain_multiplier":
			return "+%d%% DNA" % int(round(total_bonus * 100.0))
		&"dna_crystal_spawn_bonus":
			return "+%d%% spawn DNA" % int(round(total_bonus * 100.0))
		&"auto_upgrade_interval_reduction":
			return "-%d%% intervallo auto-upgrade" % int(round(total_bonus * 100.0))
		&"pickup_radius", &"projectile_range", &"targeting_range":
			return "+%.0f raggio" % total_bonus
		_:
			return "+%.2f" % total_bonus
