extends Node2D
class_name RunScene

const CellCore = preload("res://scripts/entities/cell_core.gd")
const ResourceManager = preload("res://scripts/managers/resource_manager.gd")
const UpgradeManager = preload("res://scripts/managers/upgrade_manager.gd")
const MutationManager = preload("res://scripts/managers/mutation_manager.gd")
const WaveManager = preload("res://scripts/managers/wave_manager.gd")
const HUD = preload("res://scripts/ui/hud.gd")
const MutationChoicePanel = preload("res://scripts/ui/mutation_choice_panel.gd")
const GameOverPanel = preload("res://scripts/ui/game_over_panel.gd")
const RunStats = preload("res://scripts/core/run_stats.gd")
const MutationData = preload("res://scripts/data/mutation_data.gd")
const ArenaBackdrop = preload("res://scripts/run/arena_backdrop.gd")

const DNA_PICKUP_INTERVAL_MIN := 9.0
const DNA_PICKUP_INTERVAL_MAX := 15.0
const MAX_ACTIVE_DNA_PICKUPS := 3

@onready var arena_backdrop: ArenaBackdrop = $ArenaBackdrop
@onready var enemy_container: Node2D = $EnemyContainer
@onready var projectile_container: Node2D = $ProjectileContainer
@onready var pickup_container: Node2D = $PickupContainer
@onready var core: CellCore = $CellCore
@onready var resource_manager: ResourceManager = $ResourceManager
@onready var upgrade_manager: UpgradeManager = $UpgradeManager
@onready var mutation_manager: MutationManager = $MutationManager
@onready var wave_manager: WaveManager = $WaveManager
@onready var hud: HUD = $UI/HUD
@onready var mutation_panel: MutationChoicePanel = $UI/MutationChoicePanel
@onready var game_over_panel: GameOverPanel = $UI/GameOverPanel

var arena_center: Vector2 = Vector2.ZERO
var arena_radius: float = 260.0
var gameplay_paused: bool = false
var run_finished: bool = false
var _committed_rewards: bool = false
var _active_enemy_count: int = 0
var _dna_pickup_scene: PackedScene = preload("res://scenes/entities/dna_pickup.tscn")
var _dna_spawn_timer: float = 0.0
var _rng := RandomNumberGenerator.new()

func _ready() -> void:
	_rng.randomize()
	get_viewport().size_changed.connect(_update_arena_layout)
	_update_arena_layout()
	_wire_scene()
	_start_new_run()

func _process(delta: float) -> void:
	upgrade_manager.update_runtime_systems(delta, is_gameplay_paused())
	if is_gameplay_paused():
		return

	_dna_spawn_timer -= delta
	if _dna_spawn_timer <= 0.0:
		_try_spawn_dna_pickup()
		_schedule_next_dna_pickup()

func _wire_scene() -> void:
	core.setup(self, wave_manager, projectile_container)
	wave_manager.setup(core, self, enemy_container, pickup_container, resource_manager, upgrade_manager)
	upgrade_manager.setup(resource_manager, mutation_manager)

	upgrade_manager.stats_updated.connect(_on_stats_updated)
	upgrade_manager.upgrades_changed.connect(_refresh_shop)
	resource_manager.atp_changed.connect(_on_runtime_values_changed)
	resource_manager.dna_projection_changed.connect(_on_runtime_values_changed)
	wave_manager.wave_started.connect(_on_wave_started)
	wave_manager.enemy_counts_changed.connect(_on_enemy_counts_changed)
	wave_manager.mutation_milestone_reached.connect(_on_mutation_milestone_reached)
	mutation_manager.choices_requested.connect(_on_mutation_choices_requested)
	core.health_changed.connect(_on_core_health_changed)
	core.shield_changed.connect(_on_core_shield_changed)
	core.core_destroyed.connect(_on_core_destroyed)
	upgrade_manager.free_upgrade_granted.connect(_on_free_upgrade_granted)

	hud.upgrade_requested.connect(_on_upgrade_requested)
	mutation_panel.mutation_selected.connect(_on_mutation_selected)
	game_over_panel.restart_requested.connect(_restart_run)
	game_over_panel.meta_requested.connect(func() -> void: get_tree().change_scene_to_file("res://scenes/laboratory_scene.tscn"))
	game_over_panel.menu_requested.connect(func() -> void: get_tree().change_scene_to_file("res://scenes/main_menu.tscn"))

func _start_new_run() -> void:
	gameplay_paused = false
	run_finished = false
	_committed_rewards = false
	_active_enemy_count = 0
	game_over_panel.hide_panel()
	mutation_panel.hide_panel()
	resource_manager.reset_run()
	mutation_manager.reset_run()
	upgrade_manager.reset_run()
	_schedule_next_dna_pickup()
	core.global_position = arena_center
	core.reset_run()
	wave_manager.reset_run()
	core.apply_stats(upgrade_manager.get_current_stats())
	resource_manager.set_dna_gain_multiplier(upgrade_manager.get_current_stats().dna_gain_multiplier)
	arena_backdrop.set_combat_state(1, 0)
	_refresh_hud()
	_refresh_shop()

func _restart_run() -> void:
	for projectile in projectile_container.get_children():
		projectile.queue_free()
	for pickup in pickup_container.get_children():
		pickup.queue_free()
	_start_new_run()

func _update_arena_layout() -> void:
	var viewport_size := get_viewport_rect().size
	var playfield := Rect2(
		Vector2(viewport_size.x * 0.07, viewport_size.y * 0.18),
		Vector2(viewport_size.x * 0.86, viewport_size.y * 0.56)
	)
	if is_instance_valid(hud):
		playfield = hud.get_playfield_rect(viewport_size)

	arena_center = playfield.position + (playfield.size * 0.5)
	arena_radius = min(playfield.size.x * 0.44, playfield.size.y * 0.48)
	if is_instance_valid(arena_backdrop):
		arena_backdrop.set_arena_layout(arena_center, arena_radius)
	if is_instance_valid(core):
		core.global_position = arena_center
	queue_redraw()

func get_random_spawn_position() -> Vector2:
	var angle := _rng.randf() * TAU
	var spawn_radius := arena_radius + _rng.randf_range(24.0, 52.0)
	return arena_center + Vector2.RIGHT.rotated(angle) * spawn_radius

func get_random_collectible_position() -> Vector2:
	var angle := _rng.randf() * TAU
	var distance_ratio := _rng.randf_range(0.18, 0.82)
	return arena_center + Vector2.RIGHT.rotated(angle) * (arena_radius * distance_ratio)

func is_gameplay_paused() -> bool:
	return gameplay_paused or run_finished

func _on_upgrade_requested(upgrade_id: StringName) -> void:
	if run_finished:
		return
	if upgrade_manager.purchase_upgrade(upgrade_id):
		_refresh_hud()
		_refresh_shop()

func _on_stats_updated(stats: RunStats) -> void:
	core.apply_stats(stats)
	resource_manager.set_dna_gain_multiplier(stats.dna_gain_multiplier)
	hud.set_active_mutations(upgrade_manager.get_active_mutations())
	_refresh_hud()
	_refresh_shop()

func _on_runtime_values_changed(_value = null) -> void:
	_refresh_hud()
	_refresh_shop()

func _on_wave_started(_wave: int) -> void:
	arena_backdrop.set_combat_state(max(1, wave_manager.current_wave), _active_enemy_count)
	_refresh_hud()

func _on_enemy_counts_changed(active_count: int, _pending_count: int) -> void:
	_active_enemy_count = active_count
	arena_backdrop.set_combat_state(max(1, wave_manager.current_wave), _active_enemy_count)
	_refresh_hud()

func _on_core_health_changed(_current_hp: float, _max_hp: float) -> void:
	_refresh_hud()

func _on_core_shield_changed(_current_shield: float, _max_shield: float) -> void:
	_refresh_hud()

func _on_mutation_milestone_reached(_wave: int) -> void:
	if not mutation_manager.request_choice():
		wave_manager.resume_after_mutation_choice()
		return
	gameplay_paused = true

func _on_mutation_choices_requested(options: Array[MutationData]) -> void:
	mutation_panel.show_choices(options)

func _on_mutation_selected(mutation_id: StringName) -> void:
	mutation_manager.choose_mutation(mutation_id)
	mutation_panel.hide_panel()
	gameplay_paused = false
	wave_manager.resume_after_mutation_choice()
	hud.set_active_mutations(upgrade_manager.get_active_mutations())
	_refresh_hud()
	_refresh_shop()

func _on_core_destroyed() -> void:
	if run_finished:
		return
	run_finished = true
	gameplay_paused = true
	var summary := resource_manager.build_run_summary()
	if not _committed_rewards:
		summary["dna_earned"] = resource_manager.commit_run_rewards()
		summary["best_wave"] = MetaProgression.best_wave
		_committed_rewards = true
	game_over_panel.show_summary(summary)

func _on_free_upgrade_granted(category: StringName, upgrade_name: String) -> void:
	var prefix := "Evoluzione Attacco" if category == &"attack" else "Evoluzione Difesa"
	hud.show_runtime_event("%s: %s" % [prefix, upgrade_name])
	_refresh_hud()
	_refresh_shop()

func _refresh_hud() -> void:
	hud.update_run_status(
		core.get_current_health(),
		core.get_current_stats().max_hp,
		core.get_current_shield(),
		core.get_current_stats().shield_max,
		resource_manager.atp,
		max(1, wave_manager.current_wave),
		resource_manager.get_projected_dna(),
		_active_enemy_count
	)

func _refresh_shop() -> void:
	hud.refresh_shop(upgrade_manager)
	hud.set_active_mutations(upgrade_manager.get_active_mutations())

func _draw() -> void:
	var threat_level: float = clamp((float(_active_enemy_count) / 18.0) + (float(max(1, wave_manager.current_wave)) * 0.012), 0.0, 1.0)
	draw_arc(arena_center, arena_radius * 0.34, 0.0, TAU, 56, Color(0.22, 0.68, 0.72, 0.34), 2.0)
	draw_arc(arena_center, arena_radius * 0.6, 0.0, TAU, 72, Color(0.16, 0.38, 0.42, 0.26), 2.0)
	draw_arc(arena_center, arena_radius * 0.86, 0.0, TAU, 96, Color(0.18 + (0.08 * threat_level), 0.56, 0.54 - (0.14 * threat_level), 0.46), 2.0)

	for segment_index in range(18):
		var angle: float = TAU * float(segment_index) / 18.0
		var inner: Vector2 = arena_center + Vector2.RIGHT.rotated(angle) * (arena_radius * 0.9)
		var outer: Vector2 = arena_center + Vector2.RIGHT.rotated(angle) * (arena_radius + 18.0)
		draw_line(inner, outer, Color(0.42, 0.91, 0.86, 0.12), 2.0)

	for marker_index in range(6):
		var marker_angle: float = (TAU * float(marker_index) / 6.0) + 0.26
		draw_arc(
			arena_center,
			arena_radius + 14.0,
			marker_angle - 0.13,
			marker_angle + 0.13,
			14,
			Color(1.0, 0.76, 0.42, 0.4),
			4.0
		)

func _schedule_next_dna_pickup() -> void:
	var spawn_bonus: float = upgrade_manager.get_current_stats().dna_crystal_spawn_bonus
	var min_interval: float = max(3.0, DNA_PICKUP_INTERVAL_MIN * (1.0 - spawn_bonus))
	var max_interval: float = max(min_interval + 0.5, DNA_PICKUP_INTERVAL_MAX * (1.0 - spawn_bonus))
	_dna_spawn_timer = _rng.randf_range(min_interval, max_interval)

func _try_spawn_dna_pickup() -> void:
	if run_finished or gameplay_paused:
		return
	if _count_active_dna_pickups() >= MAX_ACTIVE_DNA_PICKUPS:
		return

	var dna_pickup := _dna_pickup_scene.instantiate()
	pickup_container.add_child(dna_pickup)
	dna_pickup.global_position = get_random_collectible_position()
	var reward_amount: int = 1 + int(max(1, wave_manager.current_wave) / 10)
	dna_pickup.initialize(reward_amount, core, self)
	dna_pickup.collected.connect(resource_manager.add_runtime_dna)
	hud.show_runtime_event("Cristallo DNA rilevato")

func _count_active_dna_pickups() -> int:
	var count: int = 0
	for pickup in pickup_container.get_children():
		if pickup.is_in_group("dna_pickups"):
			count += 1
	return count
