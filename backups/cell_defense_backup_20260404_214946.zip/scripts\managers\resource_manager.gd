extends Node
class_name ResourceManager

const EnemyData = preload("res://scripts/data/enemy_data.gd")

signal atp_changed(current_atp: int)
signal dna_projection_changed(projected_dna: int)
signal kill_stats_changed(kills: int, elite_kills: int, boss_kills: int)

var atp: int = 0
var wave_reached: int = 1
var dna_bonus: int = 0
var dna_pickups_collected: int = 0
var dna_gain_multiplier: float = 1.0
var kills: int = 0
var elite_kills: int = 0
var boss_kills: int = 0

func reset_run() -> void:
	atp = 0
	wave_reached = 1
	dna_bonus = 0
	dna_pickups_collected = 0
	dna_gain_multiplier = 1.0
	kills = 0
	elite_kills = 0
	boss_kills = 0
	atp_changed.emit(atp)
	dna_projection_changed.emit(get_projected_dna())
	kill_stats_changed.emit(kills, elite_kills, boss_kills)

func add_atp(amount: int) -> void:
	atp += amount
	atp_changed.emit(atp)

func add_runtime_dna(amount: int) -> void:
	dna_bonus += amount
	dna_pickups_collected += amount
	dna_projection_changed.emit(get_projected_dna())

func set_dna_gain_multiplier(multiplier: float) -> void:
	dna_gain_multiplier = max(multiplier, 0.2)
	dna_projection_changed.emit(get_projected_dna())

func spend_atp(amount: int) -> bool:
	if amount > atp:
		return false
	atp -= amount
	atp_changed.emit(atp)
	return true

func register_enemy_defeat(enemy_data: EnemyData) -> void:
	kills += 1
	dna_bonus += enemy_data.dna_reward

	match enemy_data.tier:
		&"elite":
			elite_kills += 1
		&"boss":
			boss_kills += 1

	kill_stats_changed.emit(kills, elite_kills, boss_kills)
	dna_projection_changed.emit(get_projected_dna())

func set_wave_reached(wave: int) -> void:
	wave_reached = max(wave_reached, wave)
	dna_projection_changed.emit(get_projected_dna())

func get_projected_dna() -> int:
	var base_dna: int = max(1, (wave_reached * 2) + dna_bonus)
	return max(1, int(round(float(base_dna) * dna_gain_multiplier)))

func commit_run_rewards() -> int:
	var dna_earned := get_projected_dna()
	MetaProgression.add_dna(dna_earned)
	MetaProgression.register_wave_result(wave_reached)
	return dna_earned

func build_run_summary() -> Dictionary:
	return {
		"wave_reached": wave_reached,
		"kills": kills,
		"elite_kills": elite_kills,
		"boss_kills": boss_kills,
		"dna_pickups": dna_pickups_collected,
		"dna_earned": get_projected_dna(),
		"best_wave": max(MetaProgression.best_wave, wave_reached)
	}
