extends Node2D
class_name ArenaBackdrop

var arena_center: Vector2 = Vector2.ZERO
var arena_radius: float = 260.0
var wave_number: int = 1
var active_enemy_count: int = 0

var _rng := RandomNumberGenerator.new()
var _particles: Array[Dictionary] = []
var _time: float = 0.0

func _ready() -> void:
	_rng.randomize()
	_build_particles()
	set_process(true)

func _process(delta: float) -> void:
	_time += delta
	queue_redraw()

func set_arena_layout(new_center: Vector2, new_radius: float) -> void:
	arena_center = new_center
	arena_radius = new_radius
	_build_particles()
	queue_redraw()

func set_combat_state(new_wave: int, enemy_count: int) -> void:
	wave_number = max(new_wave, 1)
	active_enemy_count = max(enemy_count, 0)
	queue_redraw()

func _build_particles() -> void:
	_particles.clear()
	for index in range(36):
		_particles.append({
			"angle": _rng.randf_range(0.0, TAU),
			"distance": _rng.randf_range(0.18, 1.06),
			"radius": _rng.randf_range(2.0, 8.0),
			"speed": _rng.randf_range(0.06, 0.28),
			"phase": _rng.randf_range(0.0, TAU),
			"color_mix": _rng.randf()
		})

func _draw() -> void:
	var rect := Rect2(Vector2.ZERO, get_viewport_rect().size)
	draw_rect(rect, Color(0.025, 0.045, 0.07, 1.0), true)

	for index in range(16):
		var t: float = float(index) / 15.0
		var stripe_color := Color(0.03 + (t * 0.02), 0.06 + (t * 0.05), 0.09 + (t * 0.04), 0.14)
		draw_rect(Rect2(0.0, rect.size.y * t, rect.size.x, rect.size.y / 16.0 + 1.0), stripe_color, true)

	var threat: float = clamp((float(active_enemy_count) / 18.0) + (float(wave_number) * 0.015), 0.0, 1.0)
	_draw_glow(arena_center, arena_radius * 1.55, Color(0.2, 0.78, 0.72, 0.08))
	_draw_glow(arena_center + Vector2(54.0, -42.0), arena_radius * 0.9, Color(0.31, 0.74, 1.0, 0.06))
	_draw_glow(arena_center + Vector2(-58.0, 34.0), arena_radius * 0.75, Color(1.0, 0.49, 0.43, 0.04 + threat * 0.05))

	for ring_index in range(4):
		var ring_radius: float = arena_radius * (0.36 + (ring_index * 0.22)) + sin(_time * (0.5 + ring_index * 0.18)) * 4.0
		var ring_color := Color(0.18, 0.48, 0.52, 0.2 - (ring_index * 0.03))
		draw_arc(arena_center, ring_radius, 0.0, TAU, 96, ring_color, 2.0)

	var outer_rim_color := Color(0.27 + threat * 0.2, 0.64 - threat * 0.1, 0.62 - threat * 0.12, 0.94)
	draw_circle(arena_center, arena_radius + 34.0, Color(0.05, 0.11, 0.15, 1.0))
	draw_circle(arena_center, arena_radius, Color(0.08, 0.18, 0.22, 1.0))
	draw_arc(arena_center, arena_radius, 0.0, TAU, 96, outer_rim_color, 4.0)

	for segment_index in range(24):
		var angle: float = TAU * float(segment_index) / 24.0 + (_time * 0.04)
		var p0 := arena_center + Vector2.RIGHT.rotated(angle) * (arena_radius + 3.0)
		var p1 := arena_center + Vector2.RIGHT.rotated(angle) * (arena_radius - 16.0)
		draw_line(p0, p1, Color(0.52, 0.92, 0.86, 0.24), 2.0)

	for particle in _particles:
		var angle: float = float(particle["angle"]) + (_time * float(particle["speed"]))
		var distance_ratio: float = float(particle["distance"])
		var particle_position := arena_center + Vector2.RIGHT.rotated(angle + sin(_time + float(particle["phase"])) * 0.08) * (arena_radius * distance_ratio)
		var particle_color := Color(0.31, 0.92, 0.84, 0.4).lerp(Color(0.96, 0.72, 0.33, 0.5), float(particle["color_mix"]) * threat)
		var particle_radius: float = float(particle["radius"])
		_draw_glow(particle_position, particle_radius * 2.6, Color(particle_color.r, particle_color.g, particle_color.b, 0.05))
		draw_circle(particle_position, particle_radius, particle_color)

func _draw_glow(center: Vector2, radius: float, color: Color) -> void:
	for layer in range(4, 0, -1):
		var t: float = float(layer) / 4.0
		draw_circle(center, radius * t, Color(color.r, color.g, color.b, color.a * t))
